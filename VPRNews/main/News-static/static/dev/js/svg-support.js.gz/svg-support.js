Modernizr.load({
    test: Modernizr.svg,
    nope: [ "static/css/no-svg.css" ]
});
